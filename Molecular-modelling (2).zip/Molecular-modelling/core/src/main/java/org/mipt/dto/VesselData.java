package org.mipt.dto;

import com.badlogic.gdx.math.Vector2;

public record VesselData(float width, float height, Vector2 position, double wallVelocity) {}
